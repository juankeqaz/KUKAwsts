#include "box.h"


box::box(Standard_Real dx, Standard_Real dy, Standard_Real dz)
{
  _box=new BRepPrimAPI_MakeBox(dx,dy,dz);
}

box::box(Standard_Real x, Standard_Real y, Standard_Real z, Standard_Real _dx, Standard_Real _dy, Standard_Real _dz)
{
  gp_Ax2 anAxis;
  anAxis.SetLocation(gp_Pnt(x, y, z));
  _box=new BRepPrimAPI_MakeBox(anAxis,_dx,_dy,_dz);
}

box::box(gp_Pnt location, Standard_Real _dx, Standard_Real _dy, Standard_Real _dz)
{
  gp_Ax2 anAxis;
  anAxis.SetLocation(location);
  _box=new BRepPrimAPI_MakeBox(anAxis,_dx,_dy,_dz);
}

box::box(gp_Pnt location, gp_Pnt corner)
{
  _box=new BRepPrimAPI_MakeBox(location,corner);
}

box::box(gp_Ax2 axes, Standard_Real _dx, Standard_Real _dy, Standard_Real _dz)
{
  _box= new BRepPrimAPI_MakeBox(axes,_dx,_dy,_dz);
}
